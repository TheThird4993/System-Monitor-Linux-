#include <stdio.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <time.h>

int main(int argc, char *argv[]){
	struct winsize w;
	struct tm *info_tempo;
	time_t tempo_bruto;
	char texto_horario[80];

	time(&tempo_bruto);

      //tempo_bruto -= 10800;

	info_tempo = localtime(&tempo_bruto);

	strftime(texto_horario, 80, "%d/%m/%Y %H:%M:%S", info_tempo);

	ioctl(STDOUT_FILENO, TIOCGWINSZ, &w);

	int colunas = w.ws_col;

	if(!colunas) 
	    colunas = 86; 

	printf("\n");

	for(int rep1 = 0; rep1 < 2; rep1++){
	    for(int i1 = 0; i1 < colunas; i1++){
	    	    printf("-");
	    }
	    printf("\n");
	}

	char mensagem[] = "Hello, World!";
	int tam_msg = 14;
	int spaces = (colunas - tam_msg)/2;

	for(int e = 0; e < spaces; e++){
		printf(" ");
	}

	printf("%s\t%s\n", mensagem, texto_horario);

	
	for(int rep2 = 0; rep2 < 2; rep2++){
	    for(int i2 = 0; i2 < colunas; i2++){
		    printf("-");
	    }
	    printf("\n");
	}
	
	return 0;
}
