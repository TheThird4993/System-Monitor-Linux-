1.
	criar uma pasta ~/T1_coisas contendo os itens aqui presentes
2.
	digitar o comando na pasta base do buildroot
		mkdir -p package/sysmonitor
3.
	colocar no buildroot-2025.02.11/package/sysmonitor/
		Config.in
		sysmonitor.mk
4.
	inserir no arquivo package/Config.in, antes do ultimo "endmenu"
		source "package/sysmonitor/Config.in"
5.
	dar make menuconfig
6.
	no make menuconfig, apertar / e procurar por "sysmonitor" e então apertar '1'
7.
	ativar a opção
8.
	dar make e então iniciar o qemu
9.
	se o httpd não funcionar "de primeira", utilizar 
		ip route add <ip-host> dev eth0
		httpd -h /var/www

