################################################################################
# sysmonitor
################################################################################

SYSMONITOR_VERSION = 1.0
SYSMONITOR_SITE = /home/$(USER)/T1_coisas
SYSMONITOR_SITE_METHOD = local

# 1. Esta etapa compila o código usando o compilador cruzado do QEMU
define SYSMONITOR_BUILD_CMDS
	$(TARGET_CC) $(TARGET_CFLAGS) $(@D)/SysMonitorCGI.c -o $(@D)/sysmon
endef

define SYSMONITOR_INSTALL_TARGET_CMDS
	# Instala o executável (0755 = com permissão de execução +x) na pasta cgi-bin
	$(INSTALL) -D -m 0755 $(@D)/sysmon $(TARGET_DIR)/var/www/cgi-bin/sysmon
	
	# Instala o index.html (0644 = permissão normal de leitura) na raiz do site
	$(INSTALL) -D -m 0644 $(@D)/index.html $(TARGET_DIR)/var/www/index.html

	# Instala o script para rodar comando ao montar o linux
	$(INSTALL) -D -m 0755 $(@D)/S99meuscript $(TARGET_DIR)/etc/init.d/S99meuscript
endef

$(eval $(generic-package))
